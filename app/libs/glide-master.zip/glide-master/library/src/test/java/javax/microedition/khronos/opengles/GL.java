package javax.microedition.khronos.opengles;

/**
 * TODO: Figure out why this is necessary and remove it.
 * See: https://github.com/robolectric/robolectric-gradle-plugin/issues/145
 */
public interface GL {
}

